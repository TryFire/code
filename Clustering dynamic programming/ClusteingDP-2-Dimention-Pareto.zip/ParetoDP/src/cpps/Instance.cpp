#include "../headers/Instance.h"
#include <math.h>
#include<algorithm>
void Instance::getData(){
	ifstream infile;
	string data;
	infile.open(this->filename);
	infile >> data;
	this->num_point = stoi(data);
	infile >> data;
	this->dimension = stoi(data);
	this->matrix.reserve(this->num_point*this->dimension);
	for (int i = 0; i < this->num_point; ++i)
	{
		for (int j = 0; j < this->dimension; ++j)
		{
			infile >> data;
			this->matrix[i*this->dimension + j] = stof(data);
		}
	}
}

int Instance::getNumPoints() const{
	return num_point;
}

void Instance::showData(){
	for (int i = 0; i < this->num_point; ++i)
	{
		for (int j = 0; j < this->dimension; ++j)
		{
			cout << this->matrix[i*this->dimension + j] << " ";
		}
		cout << endl;
	}
}
float Instance::distance(int p1, int p2) const{
	if (p1 <= 0 || p2 <= 0){
		return 0;
	}
	float sum = 0;
	for (int i = 0; i < this->dimension; ++i)
	{
		float x1 = this->matrix[(p1-1)*this->dimension + i];
		float x2 = this->matrix[(p2-1)*this->dimension + i];
		sum += pow((x1-x2), 2);
	}
	return sqrt(sum);
}

float Instance::distance(std::vector<float> v1, std::vector<float> v2){
	return sqrt(pow(v1[0]-v2[0], 2) + pow(v1[1]-v2[1], 2));
}

std::vector<float> Instance::mean_between(int i1, int i2) const {
	/*if (i1 <= 0 || i2 <= 0 || i2 < i1){
		return NULL;
	}*/
	float x1 = 0;
	float x2 = 0;
	for (int i = i1; i <= i2; ++i)
	{
		x1 = x1 + this->matrix[(i-1)*this->dimension + 0];
		x2 = x2 + this->matrix[(i-1)*this->dimension + 1];
	}
	x1 = x1 / (i2-i1+1);
	x2 = x2 / (i2-i1+1);

	std::vector<float> v(2);
	v[0] = x1;
	v[1] = x2;
	//std::vector<float> res = ;
	return v;
}

float Instance::clustering(int i1, int i2, string type){
	if(type == "K-means"){
		return k_means(i1, i2);
	} else if(type == "K-medoids") {
		return k_medoids(i1, i2);
	} else if(type == "K-median") {
		return k_median(i1, i2);
	} else if(type == "discrete K-center") {
		return discrete_K_center(i1, i2);
	} else if(type == "continuous K-center") {
		return continuous_K_center(i1, i2);
	} else {
		return 0;
	}
	
}
float Instance::discrete_K_center(int i1, int i2){
	float res = 100000000.0;
	for (int j = i1; j <= i2; ++j)
	{
		res = min(res, max(distance(i1, j), distance(j, i2)));
	}
	return res;
}
float Instance::continuous_K_center(int i1, int i2){
	return distance(i1,i2)/2;
}
float Instance::k_means(int i1, int i2){
	std::vector<float> mean = mean_between(i1, i2);
	float sum = 0;
	for (int i = i1; i <= i2; ++i)
	{
		std::vector<float> v(2);
		v[0] = this->matrix[(i-1)*2 + 0];
		v[1] = this->matrix[(i-1)*2 + 1];
		sum = sum + pow(distance(v, mean), 2);
		
	}
	return sum/(i2-i1+1);
}
float Instance::k_medoids(int i1, int i2){
    float res = 100000000.0;
    float a =0;
    for (int I = i1; I <= i2; ++I)
    {
        for (int j = i1; j <= i2; ++j)
        {
            a = a + pow(distance(j,I),2);
        }
        res = min(res , a);
    }
    return res/ (i2-i1+1);
}
float Instance::k_median(int i1, int i2){
    float res = 100000000.0;
    float a = 0;
    for (int I = i1; I <= i2; ++I)
    {
        for (int j = i1; j <= i2; ++j)
        {
            a = a + distance(j,I);
        }
        res = min(res , a);
    }
    return res;
}