#include "../headers/Solver.h"
#include "../headers/matrix.h"
#include "../headers/Solution.h"
#include <algorithm>
#include <iostream>
#include <string>
#include <vector>
Solution Solver::solve(string type){
	
	int N = this->instance->getNumPoints();
	int K = 4;
	matrix C(N+1, N+1);

	for (int i = 0; i <= N; ++i)
	{
		C(0, i) = 0;
		C(i, 0) = 0;
	}
	for (int i = 1; i <= N; ++i)
	{
		C(i, 1) = this->instance->clustering(1, i, type);
		for (int k = 2; k <= K; ++k){
			C(i, k) = 1000000.0;
			for (int j = 1; j <= i; ++j) {
				float temp = C(j-1, k-1) + this->instance->clustering(j, i, type);
				C(i, k) = min(C(i, k), temp);
			}
		}
	}

	int i = N;
	std::vector<int> res(K);
	for (int k = K; k >=1; --k){
		for(int j = 1; j <= i; ++j) {
			float temp = C(j-1, k-1) + this->instance->clustering(j, i, type);
			if(temp == C(i, k)) {
				res[k-1] = i;
				//cout << "parti: " << j << " " << i << endl;
				i = j-1; 
				break;
			} 
		}
	}
	return Solution(C(N, K), res);
}