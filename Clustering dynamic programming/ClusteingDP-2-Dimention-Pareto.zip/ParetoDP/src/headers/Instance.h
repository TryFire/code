#ifndef INSTANCE_H
#define INSTANCE_H
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

using namespace std;
class Instance {
private:
	string filename;
	std::vector<float> matrix;
	int num_point;
	int dimension;
private:
	void getData();
	float discrete_K_center(int i1, int i2);
	float continuous_K_center(int i1, int i2);
	float k_means(int i1, int i2);
	float k_median(int i1, int i2);
	float k_medoids(int i1, int i2);
	float mean(int i1, int i2) const;
	float distance(std::vector<float> v1, std::vector<float> v2);
	std::vector<float> mean_between(int i1, int i2) const;

public:
	Instance(string fn):filename(fn){getData();};
	float distance(int p1, int p2) const;
	void showData();
	float clustering(int i1, int i2, string type);
	int getNumPoints() const;
};
#endif