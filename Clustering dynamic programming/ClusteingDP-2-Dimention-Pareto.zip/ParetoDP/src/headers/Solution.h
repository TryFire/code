#ifndef SOLUTION
#define SOLUTION
#include <iostream>
using namespace std;
class Solution
{
private:
	float cost;
	std::vector<int> cuts;

public:
	//Solution(float c):cost(c){};
	Solution();
	Solution(float c, std::vector<int> v):cost(c),cuts(v){};
	//~Solution();
	void showSolution(){
		cout << "the cost min : " << cost << endl;
		int start = 1;
		for (std::vector<int>::iterator i = cuts.begin(); i < cuts.end(); ++i)
		{
			cout << start << " to " << *i << endl;
			start = *i+1;
		}
	};
	void insert_start(int e){
		std::vector<int>::iterator it = cuts.begin();
		cuts.insert(it, e);
	};

};

#endif