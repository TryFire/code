#ifndef SLOVER_H
#define SLOVER_H
#include "Instance.h"
#include "Solution.h"
#include <string>
class Solver
{
private: 
	Instance * instance;
	Solution * solution;

public:
	Solver(Instance * ins){ instance = ins;};
	~Solver();
	Solution solve(string type);
	
};
#endif