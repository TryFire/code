#ifndef MATRIX_H_INCLUDED
#define MATRIX_H_INCLUDED

#include <vector>

struct matrix
{
  matrix(std::size_t d0, std::size_t d1) : storage_(d0 * d1), ds_{d0, d1} {}

  float operator()(std::size_t i0, std::size_t i1) const
  {
    return storage_[i0*ds_[1] + i1];
  }

  float& operator()(std::size_t i0, std::size_t i1)
  {
    return storage_[i0*ds_[1] + i1];
  }

  std::size_t size() const      { return storage_.size(); };
  std::size_t size(int n) const { return n<2 ? ds_[n] : 1; };

  private:
  std::vector<float> storage_;
  std::size_t ds_[2];
};

#endif
