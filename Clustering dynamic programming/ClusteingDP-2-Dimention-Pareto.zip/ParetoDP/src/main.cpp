#include <iostream>
#include "headers/Instance.h"
#include "headers/Solver.h"
#include "headers/Solution.h"
#include <string>

using namespace std;
int main(int argc, char const *argv[])
{	
	string measures[] = {"K-means", "K-medoids", "K-median", "discrete K-center", "continuous K-center"};


	string filename = argv[1];
	cout << " choose Clustering measures : " << endl;
	cout << " input 0 for K-means " << endl;
	cout << " input 1 for K-medoids " << endl;
	cout << " input 2 for K-median " << endl;
	cout << " input 3 for discrete K-center " << endl;
	cout << " input 4 for continuous K-center " << endl;
	cout << " your choose : ";
	int type;
	cin >> type;
	while(type > 4 || type < 0) {
		cout << "error input, please input true number : ";
		cin >> type;
	}

	//cout << "you have choosen : " << measures[type] << endl;
	
	Instance * pp = new Instance(filename);
	Solver * s = new Solver(pp);
	Solution solution = s->solve(measures[type]);
	solution.showSolution();
	return 0;
}