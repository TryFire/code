#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <stdlib.h>
#include <stdio.h>
using namespace std;

int main(){

	std::vector<int> v(3);
	std::vector<int>::iterator it;
	v[0]=1;
	v[1]=2;
	for (it = v.begin(); it < v.end(); ++it)
	{
		cout << *it << endl;
	}
	/*string data;
	ifstream infile;
	
	infile.open("data.txt");
	infile >> data;
	int i = data.find("=");
	int n = stoi(data.substr(i+1));
	infile >> data;
	i = data.find("=");
	int dimention = stoi(data.substr(i+1));
	std::vector<float> matrix;
	matrix.reserve(n*dimention);
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < dimention; ++j)
		{
			infile >> data;
			matrix[i*dimention + j] = stof(data);
		}
	}
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < dimention; ++j)
		{
			cout << matrix[i*dimention + j] << " ";
		}
		cout << endl;
	}
	return 0;*/
}

