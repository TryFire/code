open CommonAST
module NodeMap = Map.Make(String)

type color = int
type coloring = color NodeMap.t

(* obtenir le plus petit element a partir de 0 dans un list triee 
   ex : [1....] -> 0
   		[0;2..] -> 1
   		[0;1;1] -> 2
   		[0;1;2] -> 3*)
let rec get_smallest_color sorted_l acc = 
		match sorted_l with
		| [] -> acc
		| h::r -> if acc<h then acc else if acc=h then get_smallest_color r (h+1) else get_smallest_color r acc

let rec pick_color g coloration sommet =
	let list_neighb = Graph.neighbours g sommet in
	(* obtenir les colors de voisins de le sommet *)
	let list_color = 
		List.fold_left 
		(fun acc voisin_de_sommet -> (NodeMap.find voisin_de_sommet coloration)::acc)
		[] 
		list_neighb 
	in
	(* obtenir la list triee par List.sort et compare *)
	let sorted_list_color = (List.sort compare list_color) in
	(* obtenir la puls petit element *)
	get_smallest_color sorted_list_color 0

let rec colorize g =
	(* choisir un sommet de degre minimal dans g *)
	let sommet = Graph.min_degree g in
	match sommet with
	(* si g n'est pas empty *)
	| Some(s) -> 
		(* construire le g' obtenue en retirant n de g *)
		let g_del = Graph.del_node g s in
		(* coloter g' *)
		let g_del_colore = colorize g_del in
		(* obtenir le plus petit color par les couleurs deja colore *)
		let color_smallest = pick_color g g_del_colore s in
		(* ajouter le sommet et son color a la Map *)
		NodeMap.add s color_smallest g_del_colore
	(* si g est empty *)
	| None -> 
		(* initialiser la Map *)
		NodeMap.empty