open CommonAST
open IndexedGotoAST
module Igl = IndexedGotoLiveness
module IG = IndexedGotoAST

type liveness_info = { live_in: int * string list array;
                       live_out: int * string list array }

let is_change = ref true

(* succ_to_pred : int list array -> int list array 
   on veux obtenir le table de pred par le table de succ*)

let succ_to_pred succ = 
	let length = Array.length succ in
	(* initiation du table pred *)
	let pred = Array.make length [] in
	(* calculer le table de pred *)
	Array.iteri
	(* fun n le ->  ...
	   ou le est le type de int list 
	   n est indice de table succ, sera valeur de table pred

	   on doit prendre chaque element de la list le -> e, as l'indice de table pred *) 
	( fun n le -> 
	  List.iter 
	  (* fun e -> ...
	  	 obtenir e-ieme list de table pred et ajoute n sur la list, et mise a jour sur le table *)
	  ( fun e -> 
	  	(* obtenir la list de indice de n de table pred *)
	  	let l = Array.get pred e in
	  	(* ajouter n sur la list d'indice e de table pred *)
	  	Array.set pred e (n::l)
	  )
	  le 
	)
	succ;
	(* renvoie le table de pred *)
	pred

let rec access_1 instr pred kill gen liveness_info = 

  	match instr with
  	| (n, IG.Sequence((n1, i1),(n2, i2))) -> 
  		(* obtenir la table de live_in *)
  		let live_in = liveness_info.live_in in
  		(* obtenir la table de live_out *)
  		let live_out = liveness_info.live_out in
  		(* obtenir la list ancient de live_in de Sequence *)
  		let my_live_in = Array.get live_in n in
  		(* obtenir la list ancient de live_our de Sequence *)
  		let my_live_out = Array.get live_out n in
  		(* obtenir la list de live_in de l'instruction gauche *)
  		let live_in_n1 = Array.get live_in n1 in
  		(* obtenir la list de live_out de l'instruction droite *)
  		let live_out_n2 = Array.get live_out n2 in
  		(* si au moins un des nouveaux lists de live_in, live_out est change, *)
  		if (Igl.compare_list my_live_in live_in_n1) = false || (Igl.compare_list my_live_out live_out_n2) = false
  		(* alors is_change <- true *)
  		then is_change := true;
  		(* live_in[n] = live_in[n₁] *)
  		Array.set live_in n (live_in_n1);
  		(* live_out[n] = live_out[n₂] *)
  		Array.set live_out n (live_out_n2);
  		(* recursive de gauche *)
  		access_1 (n1, i1) pred kill gen liveness_info;
  		(* recursive de droite *)
  		access_1 (n2, i2) pred kill gen liveness_info


  	| (n, _)-> 
  		(* obtenir le table de live_in *)
  		let live_in = liveness_info.live_in in
  		(* obtenir le table de live_out *)
  		let live_out = liveness_info.live_out in
  		(* 
		 In[p]  =  ⋃ᵣ Out[r]                       r ∈ Pred[p]  
  		 Out[p]  =  (In[p] \ Kill[p]) ∪ Gen[p]
  		*)
  		(* obtenir list de mes preds *)
  		let my_pred = Array.get pred n in
  		(* obtenir list de mes live_in ou les elements sont variables *)
  		let my_in = Array.get live_in n in
  		(* obtenir list de mes live_out ou les elements sont variables *)
  		let my_out = Array.get live_out n in
  		(* obtenir list des variables de ecriture *)
  		let my_kill = Array.get kill n in
  		(* obtenir list des variables de lecture *)
  		let my_gen = Array.get gen n in
  		(* Int[p]  =  ⋃ᵣ Out[r]   r ∈ Pred[p]   *)
  		let new_in = 
  			List.fold_right 
  			(* index_succ : indice de mon pred *)
  			( fun index_succ b -> 
  				(* in_succ : list de live_in de ce pred *)
  				let in_succ = Array.get live_out index_succ in 
  				(* union my_live_out avec list de live_in de ce pred *)
  				(Igl.union_variable b in_succ) )
  			my_pred
  			my_in
  		in 
  		if (Igl.compare_list my_in new_in) = false then is_change := true;
  		(*new_live_out <- Int[p] \ Kill[p] *)
  		let new_out = Igl.minus_variable new_in my_kill in
  		(*new_live_out <- (In[p] \ Kill[p]) ∪ Gen[p] *)
  		let new_out = Igl.union_variable new_out my_gen in
  		if (Igl.compare_list my_out new_out) = false then is_change := true;
  		(* mise a jour de la list live_in dans le table *)
  		Array.set live_in n new_in;
  		(* mise a jour de la list de live_out dans le table *)
  		Array.set live_out n new_out

let rec get_gen instr gen = match instr with
	| (n, IG.Sequence((n1, i1),(n2, i2))) -> 
  		(* recursive *)
  		get_gen (n1, i1) gen;
  		(* recursive *)
  		get_gen (n2, i2) gen
  	| (n, IG.Set(l, e)) -> 
  		Array.set gen n [(n, Igl.get_location l)]
  	| _ -> ()

and get_kill instr pred gen kill = match instr with
	| (n, IG.Sequence((n1, i1),(n2, i2))) -> 
  		(* recursive *)
  		get_kill (n1, i1) pred gen kill;
  		(* recursive *)
  		get_kill (n2, i2) pred gen kill
  	| (n, IG.Set(l, e)) -> 
  		let name = Igl.get_location l in
  		Array.set kill n (get_pred_definition pred gen name n)
  	| _ -> ()

and get_pred_definition pred gen name n = 
	let l = Array.get pred n in
	if (List.length l) = 0 then []
	else
		List.fold_right (fun a b -> ((get_definition_indice gen name a)@(get_pred_definition pred gen name a)@b)) l [] 

and get_definition_indice gen name indice = 
	let lgen = Array.get gen indice in 
	if List.length lgen > 0 then 
		begin
			let (n, e_name) = List.hd lgen in
			if e_name = name then [(n, e_name)]
			else []
		end
	else 
	[]



let access instr = 
	print_string "==============start access================= \n";
	let n = 
  		match instr with
  		(* s'il y a plusieurs instructions *)
  		| (n, IG.Sequence(i1, i2)) -> n+1
  		(* s'il y a seulement un ou pas *)
  		| _ -> 1
  	in
	let successeur = Igl.mk_succ_table instr in
	let pred = succ_to_pred successeur in
	let table_kill = Array.make n [] in
	let table_gen = Array.make n [] in
	get_gen instr table_gen;
	get_kill instr pred table_gen table_kill;
	(*
	Igl.get_gen_kill instr table_gen table_kill;
	Igl.print_table_d successeur "successeur";
	Igl.print_table_d pred "pred";
	Igl.print_table table_kill "table_kill";
	Igl.print_table table_gen "table_gen";
*)
	let table_live_in = Array.make n [] in
	let table_live_out = Array.make n [] in
	let info = { live_in = table_live_in;
	  			 live_out = table_live_out; }
	in
	is_change := true;
	(* tant que au moins un list sur liveness_info est mise a jour *)
	while (!is_change) = true do
		is_change := false;
		(* il faut autre iteration *)
		access_1 instr pred table_kill table_gen info;
	done;
	(* afficher  *)
	Igl.print_liveness info;
	(* renvoie liveness_info *)
	print_string "============fin access============== \n";
	info

