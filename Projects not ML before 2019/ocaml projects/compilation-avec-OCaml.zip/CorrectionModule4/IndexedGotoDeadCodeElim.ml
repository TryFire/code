open CommonAST
module IG = IndexedGotoAST

(* renvoie true si les elements de list 2 sont tous dans list 1, false sinon *)
let list_is_in_list l1 l2 = 
	(* renvoie true si element e est dans list 1, false sinon *)
	let rec element_is_in_list l1 e = 
		List.fold_left (fun a b_in_list -> if e = b_in_list then true else (false||a) ) false l1
	in
	(* verifier si tous les element de l2 sont dans l1 *)
	List.fold_left(fun a b_in_list -> a && (element_is_in_list l1 b_in_list) ) true l2 


(* calcul des informations de vivacité des variables *)
(* step: IndexedGotoAST.instruction -> IndexedGotoAST.instruction * bool *)
let rec step_in instr kill liveness_info = 
	match instr with
	| (n, IG.Sequence((n1, i1),(n2, i2))) -> 
		(* obtenir (instruction * bool) a gouche *)
		let (i1_vive, i1_is_vive) = step_in (n1, i1) kill liveness_info in
		(* obtenir (instruction * bool) a droite *)
		let (i2_vive, i2_is_vive) = step_in (n2, i2) kill liveness_info in
		(* si au moins instruction a ete elimine) *)
		if (i1_is_vive = true || i2_is_vive = true) 
		then 
			(* cet Sequence n'est pas vivacite *)
			((n, IG.Sequence(i1_vive, i2_vive)), true)
		(* sinon *)
		else 
			(* cet Sequence est vivacite *)
			(instr, false)

	| (n, i) -> 
		(* obtenir la list de ecriture de n-ieme instruction *)
		let l_kill = Array.get kill n in
		(* obtenir la table de live_out *)
		let l_live_out = IndexedGotoLiveness.(liveness_info.live_out) in
		(* obtenir la list de live_out de  n-ieme instruction*)
		let l_live_out = Array.get l_live_out n in
		(* verifier si l_kill sont tous dans l_live_out *)
		if (list_is_in_list l_live_out l_kill) then 
			(* si tous dans live_out, cet instruction est vivacite *)
			(instr, false)
		else 
			begin
				Printf.printf " find %d-------\n" n;
			(* non vivacite *)
			((n, IG.Nop), true)
			end
			


let step instr = 
	let n = 
  		match instr with
  		(* s'il y a plusieurs instructions *)
  		| (n, IG.Sequence(i1, i2)) -> n+1
  		(* s'il y a seulement un ou pas *)
  		| _ -> 1
  	in
	let table_kill = Array.make n [] in
	let table_gen = Array.make n [] in
	IndexedGotoLiveness.get_gen_kill instr table_gen table_kill;
	let info : IndexedGotoLiveness.liveness_info = IndexedGotoLiveness.liveness instr in
	step_in instr table_kill info


let rec dead_code_elim instr =
	let (onestep_i, is_change) = step instr in
	if is_change 
	then 
		dead_code_elim onestep_i
	else
		onestep_i




(*  dead_code_elim: IndexedGotoAST.instruction -> IndexedGotoAST.instruction *)











