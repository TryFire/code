module IG = IndexedGotoAST
module IGL = IndexedGotoLiveness
open CommonAST

let liveness = ref IGL.({live_in = Array.make 1 [];
						 live_out = Array.make 1 []})


let rec add_interferences g i =
	match i with
	(* si Sequence *)
	| (n,IG.Sequence(i1,i2)) -> 
		(* recursive gauche et obtenir le graph de gauche *)
		let g1 = add_interferences g i1 in
		(* recursive gauche *)
		add_interferences g1 i2

	(* si Set(Identifier dest, Location(Identifier id)) *)
	| (n,IG.Set(GotoAST.Identifier(Id(dest)),GotoAST.Location(GotoAST.Identifier(Id(v))))) -> 
		let list_live_out_n = !liveness.live_out.(n) in
		(* itertive de list de live_out en point de n de programme *)
		List.fold_left 
		(* si variable s de list live_out = v alors ne renvoie que g
		   sinon ajouter les edge entre dest et variable s *)
		(fun g s -> if s <> v then Graph.add_edge g dest s else g)
		(* le graph *)
		g 
		(* la list de variable live_out *)
		list_live_out_n

	(* si Set(Identifier dest, _ *)
	(* faire la meme chose que precedent *)
	| (n,IG.Set(GotoAST.Identifier(Id(dest)),_)) -> 
		let list_live_out_n = !liveness.live_out.(n) in
		List.fold_left 
		(fun g s -> try Graph.add_edge g dest s with Graph.InvalidNode -> g) 
		g 
		list_live_out_n
	(* si les autres instruction, renvoie graph directement *)
	| (n,_) -> 
		g


let interference_graph function_info =
	(* ajouter tous nodes les variables locals a la graph *)
	let graph = 
		Symb_Tbl.fold 
		(* les variables locals dans un function *)
		(fun key value g -> Graph.add_node g key) 
		IG.(function_info.locals) 
		(* initialiser graph *)
		Graph.empty
	in
	(* appeler function liveness pour obtenir liveness_info *)
	liveness := IGL.liveness IG.(function_info.code);
	(* construire le graph par les instruction de function *)
	add_interferences graph IG.(function_info.code)

