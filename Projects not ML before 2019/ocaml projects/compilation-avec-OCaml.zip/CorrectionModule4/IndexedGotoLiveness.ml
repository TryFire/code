open CommonAST
open GotoAST
module IG = IndexedGotoAST

type succ_table = int list array

type liveness_info = { live_in: string list array;
                       live_out: string list array }

let is_change = ref true

(* mk_succ_table: IndexedGotoAST.instruction -> succ_table *)
let mk_succ_table instr = 
  (* initiation de table *)
  let array = 
  	match instr with
  	(* s'il y a plusieurs instructions *)
  	| (n, IG.Sequence(i1, i2)) -> Array.make (n+1) [] 
  	(* s'il y a seulement un ou pas *)
  	| _ -> Array.make 1 [] 
  in

  (* obtenir l'indice d'instruction de Lable par label *)
  let rec get_index_label instr s = 
  	match instr with
  	| (n, IG.Sequence(i1, i2)) -> (get_index_label i1 s) + (get_index_label i2 s)
  	(* si je le trouve, renvoie l'indice, 0 sinon *)
  	| (n, IG.Label(l)) -> if l = s then n else 0
  	| (n, _) -> 0
  in

  (* construire le table de successeur *)
  let rec mk_in ins = 
  	match ins with
  	(* succ(n1) <- [n2]; succ(n2) <- succ(n) *)
  	| (n, IG.Sequence((n1, i1),(n2, i2))) -> 
  	  Array.set array n1 [n2];
  	  Array.set array n2 (Array.get array n);
  	  mk_in (n1, i1);
  	  mk_in (n2, i2)
  	(* succ(goto) <- [l'indice de label] *)
	| (n, IG.Goto(l)) -> Array.set array n [(get_index_label instr l)]
	(* succ(go_when) <- succ(go_when) + l'indice de lable *)
  	| (n, IG.ConditionalGoto(l,e)) -> 
  	  let one = Array.get array n in
  	  let n_l = (get_index_label instr l) in
  	  let total = n_l :: one in
  	  Array.set array n total
  	| _ -> ()
  in
  (* appele de function *)
  mk_in instr;
  (* construire le type *)
  let succ : succ_table = array in
  succ



let print_table t s = 
  Array.iteri 
  ( fun n l -> Printf.printf "number:%d  %s : " n s; (List.iter 
  													 (fun e -> Printf.printf " %s " e) 
  													 l);
	print_string "\n")

  t

let print_table_d t s = 
  Array.iteri 
  ( fun n l -> Printf.printf "number:%d  %s : " n s; (List.iter 
  													 (fun e -> Printf.printf " %d " e) 
  													 l);
	print_string "\n")

  t


(* liveness: IndexedGotoAST.instruction -> liveness_info *)

(*
  	In[p]  =  (Out[p] \ Kill[p]) ∪ Gen[p]
  	Out[p]  =  ⋃ᵣ In[r]                       r ∈ Succ[p]  


  	Gen[p]  =  { x | i lit la valeur de x }
 	Kill[p]  =  { x }        pour i ≡ x := ...
  	Kill[p]  =  ∅            pour i ≡ print, goto


  	(n, Sequence((n₁, i₁), (n₂, i₂))
    live_in[n] = live_in[n₁]
    live_out[n] = live_out[n₂]
*)

(* union deux list de variable {x, y} U {x, z} -> {x, y, z} *)
let union_variable l1 l2 = 
  (* renvoie true si variabke est deja dans list l, false sinon *)
  let rec is_dans_l l v = 
  	match l with
  	| [] -> false
 	| h::r -> if h = v then true else is_dans_l r v
  in
  (* ajouter variable dans list l et le renvoie*)
  let insert_in_l l v = 
  	v::l 
  in
  (* union deux list de variable, {x, y} U {x, z} -> {x, y, z} *)
  let rec union_list l1 l2 = 
  	match l2 with
  	| [] -> l1
  	| h::r -> if(is_dans_l l1 h) 
  			  then union_list l1 r 
  			  else 
  			  	begin
  			  		union_list (insert_in_l l1 h) r
  			  	end
  in
  union_list l1 l2

(* l'ensembe l1 - l'ensemble l2 : {2;1;5} - {1;6} -> {2;5} *)
let minus_variable l1 l2 = 
  let rec is_dans_l l v = 
  	match l with
  	| [] -> false
 	| h::r -> if h = v then true else is_dans_l r v
  in
  if ((List.length l2 = 0) || (is_dans_l l1 (List.hd l2)) = false)  then l1
  else 
  begin
  	let v = List.hd l2 in
  	let rec minux l1 v = 
  		match l1 with
  		| [] -> l1
  		| h::r -> if h = v then r else (h :: (minux r v))
  	in
  	minux l1 v
  end
  
(* si les contents de list 1 et list 2 sont la meme, alors renvoie true (l1[n] = l2[n]) *)
let rec compare_list l1 l2 = 
 	match l1, l2 with
 	| [], [] -> true
 	| [], _ | _, [] -> false
 	| h1::r1, h2::r2 -> if h1=h2 then compare_list r1 r2 else false

(* "a.b.c.d" -> ["a"; "a.b";"a.b.c"] *)
let get_name_from_string str = 
	let l = String.split_on_char '.' str in
	let rec f l acc = match l with
		| [] -> failwith "sss"
		| [v] -> []
		| h::r -> (acc^h) :: (f r (acc^h^"."))
	in
	f l ""

(*

instr : instruction
successeur : succ_table = int list array
kill : string list array
gen : string list array
liveness_info : liveness_info = { live_in: string list array;
                                  live_out: string list array }

*)
let rec liveness_1 instr successeur kill gen liveness_info = 

  	match instr with
  	| (n, IG.Sequence((n1, i1),(n2, i2))) -> 
  		(* obtenir la table de live_in *)
  		let live_in = liveness_info.live_in in
  		(* obtenir la table de live_out *)
  		let live_out = liveness_info.live_out in
  		(* obtenir la list ancient de live_in de Sequence *)
  		let my_live_in = Array.get live_in n in
  		(* obtenir la list ancient de live_our de Sequence *)
  		let my_live_out = Array.get live_out n in
  		(* obtenir la list de live_in de l'instruction gauche *)
  		let live_in_n1 = Array.get live_in n1 in
  		(* obtenir la list de live_out de l'instruction droite *)
  		let live_out_n2 = Array.get live_out n2 in
  		(* si au moins un des nouveaux lists de live_in, live_out est change, *)
  		if (compare_list my_live_in live_in_n1) = false || (compare_list my_live_out live_out_n2) = false
  		(* alors is_change <- true *)
  		then is_change := true;
  		(* live_in[n] = live_in[n₁] *)
  		Array.set live_in n (live_in_n1);
  		(* live_out[n] = live_out[n₂] *)
  		Array.set live_out n (live_out_n2);
  		(* recursive de gauche *)
  		liveness_1 (n1, i1) successeur kill gen liveness_info;
  		(* recursive de droite *)
  		liveness_1 (n2, i2) successeur kill gen liveness_info


  	| (n, _)-> 
  		(* obtenir le table de live_in *)
  		let live_in = liveness_info.live_in in
  		(* obtenir le table de live_out *)
  		let live_out = liveness_info.live_out in
  		(* 
		 In[p]  =  (Out[p] \ Kill[p]) ∪ Gen[p]
  		 Out[p]  =  ⋃ᵣ In[r]                       r ∈ Succ[p]  
  		*)
  		(* obtenir list de mes successeurs *)
  		let my_succ = Array.get successeur n in
  		(* obtenir list de mes live_in ou les elements sont variables *)
  		let my_in = Array.get live_in n in
  		(* obtenir list de mes live_out ou les elements sont variables *)
  		let my_out = Array.get live_out n in
  		(* obtenir list des variables de ecriture *)
  		let my_kill = Array.get kill n in
  		(* obtenir list des variables de lecture *)
  		let my_gen = Array.get gen n in
  		(* Out[p]  =  ⋃ᵣ In[r]   r ∈ Succ[p]   *)
  		let new_out = 
  			List.fold_right 
  			(* index_succ : indice de mon successeur *)
  			( fun index_succ b -> 
  				(* in_succ : list de live_in de ce successeur *)
  				let in_succ = Array.get live_in index_succ in 
  				(* union my_live_out avec list de live_in de ce successeur *)
  				(union_variable b in_succ) )
  			my_succ 
  			my_out
  		in 
  		if (compare_list my_out new_out) = false then is_change := true;
  		(*new_live_in <- Out[p] \ Kill[p] *)
  		let new_in = minus_variable new_out my_kill in
  		(*new_live_in <- (Out[p] \ Kill[p]) ∪ Gen[p] *)
  		let new_in = union_variable new_in my_gen in
  		if (compare_list my_in new_in) = false then is_change := true;
  		(* mise a jour de la list live_in dans le table *)
  		Array.set live_in n new_in;
  		(* mise a jour de la list de live_out dans le table *)
  		Array.set live_out n new_out

(* obtenir les table de variables de lecture et ecriture sur chaque point d'instruction *)
and get_gen_kill instr gen kill = 
  	match instr with
  	| (n, IG.Sequence((n1, i1),(n2, i2))) -> 
  		(* recursive *)
  		get_gen_kill (n1, i1) gen kill;
  		(* recursive *)
  		get_gen_kill (n2, i2) gen kill
  	| (n, IG.Print(e)) -> 
  		(* seulement les variable de lecture *)
  		Array.set gen n (get_variable e)
  	| (n, IG.Set(l, e)) -> 
  		(* obtenir les variable de lecture *)
  		let g = get_variable e in
  		(* obtenir les variable de ecriture *)
  		let k = get_location l in
  		(* seulement un variable de list de kill d'instruction SET *)
  		let str = List.hd k in
  		(* si variable de ecriture contient . par example a.b.c va veut dire 
  		   cet instruction lire variable a et a.b
  		   apres ecriture sur a.b.c *)
  		if (String.contains str '.') then
  			(* mise a jour les variables de lecture *)
  			Array.set gen n (union_variable g (get_name_from_string str))
  		else
  			Array.set gen n g;
  		Array.set kill n k
  	| (n, IG.Goto(l)) -> 
  		(* il n'y pas des variables de ecriture ou lecture *)
  		()
  	| (n, IG.ConditionalGoto(l,e)) -> 
  		(* seulement les variable de lecture *)
  		Array.set gen n (get_variable e)
  	| (n, IG.Nop) -> 
  		(* il n'y pas des variables de ecriture ou lecture *)
  		()
  	| (n, IG.Return(e)) -> 
  		(* seulement les variable de lecture *)
  		Array.set gen n (get_variable e)
 	| (n, IG.Label(l)) -> 
 		(* il n'y pas des variables de ecriture ou lecture *)
 		()

and get_location loca = match loca with
  | Identifier (Id id) -> 
  	(* id est le nom de variable *)
  	[id]

  | BlockAccess (a, i) ->
  	let Literal(Int(indice)) = i in
  	let parent = get_variable a in
  	[(List.hd parent)^"."^(string_of_int indice)]

(* obtenir les noms des variables dans un expression *)
and get_variable expr = match expr with
  | Literal lit -> []

  | Location loc -> get_location loc
    
  | UnaryOp(uop, e) -> get_variable e   
      
  | BinaryOp(bop, e1, e2) -> 
  	union_variable (get_variable e1) (get_variable e2)

  | NewBlock(e) -> get_variable e

  | FunCall(Id id, params) -> 
  	let variables = 
  		List.fold_right
        (fun e l -> union_variable l (get_variable e))
        params
        []
    in variables

(* afficher les tables de liveness_info *)
let print_liveness info = 
	let live_in = info.live_in in
	let live_out = info.live_out in
	let rec print_list l = match l with
		| [] -> ()
		| h :: r -> Printf.printf " %s" h; print_list r
	in
	Array.iteri (fun n l -> Printf.printf "number :%d , in: " n; print_list l; print_string " out : "; print_list (Array.get live_out n);print_string "\n" ) live_in


(* liveness: IndexedGotoAST.instruction -> liveness_info *)
let rec liveness instr = 
	let n = 
  		match instr with
  		(* s'il y a plusieurs instructions *)
  		| (n, IG.Sequence(i1, i2)) -> n+1
  		(* s'il y a seulement un ou pas *)
  		| _ -> 1
  	in
	let successeur = mk_succ_table instr in
	let table_kill = Array.make n [] in
	let table_gen = Array.make n [] in
	get_gen_kill instr table_gen table_kill;
	print_table_d successeur "successeur";
	print_table table_kill "table_kill";
	print_table table_gen "table_gen";
	let table_live_in = Array.make n [] in
	let table_live_out = Array.make n [] in
	let info = { live_in = table_live_in;
	  			 live_out = table_live_out; }
	in
	is_change := true;
	(* tant que au moins un list sur liveness_info est mise a jour *)
	while (!is_change) = true do
		is_change := false;
		(* il faut autre iteration *)
		liveness_1 instr successeur table_kill table_gen info;
	done;
	(* afficher  *)
	print_liveness info;
	(* renvoie liveness_info *)
	info
	
  



